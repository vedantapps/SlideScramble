//
//  KeynoteApp.swift
//  SlideScramble
//
//  Created by Vedant Malhotra on 4/17/23.
//

import SwiftUI

struct KeynoteApp: View {
    
    @State var currentKeynote = "Keynote1"
    
    var body: some View {
        HStack(spacing: 0) {
            
            // Keynote Sidebar
            VStack {
                Button {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeKeynote"), object: self, userInfo: nil)
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(Color(red: 0.93, green: 0.38, blue: 0.41))
                        .font(.system(size: 32, weight: .regular, design: .default))
                }
                .padding(.trailing, 60)
                .padding(.top)
                
                ScrollView {
                    ForEach((1..<8)) { count in
                        
                        Button {
                            currentKeynote = "Keynote\(count)"
                        } label: {
                            HStack {
                                Text("\(count)")
                                    .padding(.leading, 5)
                                    .padding(.top, 30)
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                                Image("Keynote\(count)")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(maxHeight: 50)
                            }
                        }
                        .padding(.leading, 4)
                    }
                    
                }
                .padding(.top)
                Spacer()
            }
            .background(.thinMaterial)
            .frame(maxWidth: 140)
            
            VStack(spacing: 0) {
                HStack(alignment: .center) {
                    Spacer()
                    Image("KeynoteIcon")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 30)
                    
                    Text("WWDC23 Keynote")
                        .font(.headline)
                        .padding(.trailing, 50)
                    
                    Spacer()
                    
                }
                .padding(.leading)
                .frame(height: 70)
                .background(.thickMaterial)
                
                Spacer()
                
                Image(currentKeynote)
                    .resizable()
                    .scaledToFit()
                    .padding(50)
                
                Spacer()
                
            }
            .background(.white)
        }
        .edgesIgnoringSafeArea(.all)
    }
}

struct KeynoteApp_Previews: PreviewProvider {
    static var previews: some View {
        KeynoteApp()
    }
}
