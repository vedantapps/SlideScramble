//
//  ARExperienceApp.swift
//  SlideScramble
//
//  Created by Vedant Malhotra on 4/18/23.
//

import SwiftUI
import QuickLook
import ARKit

struct ARExperienceApp: View {
    
    @State var showARView = false
    
    var body: some View {
        HStack(spacing: 0) {
            // AR App Sidebar
            VStack {
                Button {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeAR Experience"), object: self, userInfo: nil)
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(Color(red: 0.93, green: 0.38, blue: 0.41))
                        .font(.system(size: 32, weight: .regular, design: .default))
                }
                .padding(.trailing, 30)
                .padding(.top)
                Spacer()
            }
            .frame(width: 100)
            .background(.thinMaterial)
            
            
            VStack(spacing: 20) {
                Spacer()
                HStack {
                    Spacer()
                    Image(systemName: "camera.viewfinder")
                        .font(.system(size: 80, weight: .bold, design: .rounded))
                        .padding(.top, 30)
                    Spacer()
                }
                
                Text("WWDC 2023 AR Ticket")
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                    .padding()
                
                Text("Prepare for WWDC 2023 with this interactive AR experience.")
                    .font(.system(size: 22, weight: .medium, design: .rounded))
                
                Button {
                    showARView = true
                } label: {
                    HStack {
                        Text("Load Experience")
                        Image(systemName: "arrow.right.circle")
                    }
                    .font(.system(size: 32, weight: .medium, design: .rounded))
                }
                
                Text("Note - The camera feed is unavilable for ARKit if this project is compiled on an iPad. If compiled through Xcode onto the iPad, it works as intended.")
                
                if showARView {
                    ARPreview()
                }
                
                Spacer()
                
            }
            .multilineTextAlignment(.center)
            .padding(.horizontal)
            .background(.black)
            .foregroundColor(.white)
            .onAppear {
                showARView = false
            }
        }
    }
}

struct ARExperienceApp_Previews: PreviewProvider {
    static var previews: some View {
        ARExperienceApp()
    }
}


// UIViewControllerRepresentable for ARKit
struct ARPreview: UIViewControllerRepresentable {
    typealias UIViewControllerType = WWDCTicket
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(parentView: self)
    }
    
    func makeUIViewController(context: Context) -> WWDCTicket {
        let view = WWDCTicket()
        return view
    }
    
    func updateUIViewController(_ uiViewController: WWDCTicket, context: Context) {
    }
    
    class Coordinator: NSObject {
        var parentView: ARPreview
        init(parentView: ARPreview) {
            self.parentView = parentView
        }
    }
    
}

// AR File
class WWDCTicket: UIViewController, QLPreviewControllerDataSource {
    let fileName = "WWDCTicket"
    let fileType = "usdz"
    
    override func viewDidAppear(_ animated: Bool) {
        let previewController = QLPreviewController()
        previewController.dataSource = self
        present(previewController, animated: true, completion: nil)
    }
    
    func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
        return 1
    }
    
    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        guard let fileLocation = Bundle.main.path(forResource: fileName, ofType: fileType) else {
            fatalError("Error opening file.")
        }
        
        let url = URL(fileURLWithPath: fileLocation)
        let arPreview = ARQuickLookPreviewItem(fileAt: url)
        arPreview.allowsContentScaling = true
        return arPreview
    }
}
