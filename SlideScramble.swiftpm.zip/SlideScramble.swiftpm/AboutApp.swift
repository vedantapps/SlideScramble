//
//  AboutApp.swift
//  SlideScramble
//
//  Created by Vedant Malhotra on 4/13/23.
//

import SwiftUI

struct AboutApp: View {
    
    @State var appPass: String
    @State var appName = "SlideScramble"
    @State var appImage = "SlideScrambleIcon"
    @State var appDescription = "Made by Vedant. Interface built in SwiftUI - WWDC 2023 Swift Student Challenge"
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeabout"), object: self, userInfo: nil)
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(Color(red: 0.93, green: 0.38, blue: 0.41))
                        .font(.system(size: 32, weight: .regular, design: .default))
                }
                .padding(.leading)
                .padding(.top)
                Spacer()
            }
            
            HStack {
                Image(appImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 120)
                    .padding([.leading, .trailing], 30)
                    .shadow(radius: 5)
                VStack(alignment: .leading) {
                    Text(appName)
                        .font(.system(size: 30, weight: .medium))
                    Text("Version 1.0")
                        .font(.system(size: 15, weight: .regular))
                        .foregroundColor(.gray)
                    Text(appDescription)
                        .font(.system(size: 15, weight: .regular))
                        .foregroundColor(.gray)
                        .padding(.top)
                }
            }
            .padding([.trailing, .bottom])
            .padding(.top, 4)
            
            Spacer()
        }
        .background(.white)
        .onAppear {
            switch appPass {
            case "Messages":
                appName = "Messages"
                appImage = "MessageIcon"
                appDescription = "For all your messaging needs. Built with SwiftUI."
            case "Keynote":
                appName = "Keynote"
                appImage = "KeynoteIcon"
                appDescription = "For all your presentation needs. Built with SwiftUI."
            case "Notes":
                appName = "Notes"
                appImage = "NotesIcon"
                appDescription = "For all your note-taking needs. Built with SwiftUI, UIKit, and PecilKit."
            case "Countdown":
                appName = "Countdown"
                appImage = "CountdownIcon"
                appDescription = "Count down the days until WWDC 2023! Built with SwiftUI."
            case "AR Experience":
                appName = "AR Experience"
                appImage = "ARIcon"
                appDescription = "An interactive AR Experience! Built with SwiftUI, QuickLook, and ARKit."
            default:
                appName = "SlideScramble"
                appImage = "SlideScrambleIcon"
                appDescription = "Made by Vedant. Interface built in SwiftUI - WWDC 2023 Swift Student Challenge"
            }
        }
        
    }
}

struct AboutApp_Previews: PreviewProvider {
    static var previews: some View {
        AboutApp(appPass: "SlideScramble")
    }
}
