import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            StartView()
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        .statusBar(hidden: true)
    }
}
