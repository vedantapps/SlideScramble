//
//  DesktopView.swift
//  SlideScramble
//
//  Created by Vedant Malhotra on 4/8/23.
//

import SwiftUI

struct DesktopView: View {
    
    let clockTimer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State var time = "9:41 AM"
    @State var appName = "SlideScramble"
    @State var showDock = false
    @State var menuBarID = 0
    @State var restartAppNotif = false
    @State var restartApp = false
    
    // Spotlight/Help
    @State var showSpotlight = false
    let closeSpotlight = NotificationCenter.default.publisher(for: NSNotification.Name("closeSpotlight"))
    
    // Keynote File
    @State var offset = CGSize.zero
    @State var dragKeynote = false
    @State var showIntroMessage = false
    @State var showIntroMessageSecondary = false
    @State var keynoteZindex = 10.0
    
    // About App
    @State var showAboutApp = false
    @State var showMainAboutApp = false
    @State var aboutAppPosition = CGPoint(x: 500, y: 150)
    @State var aboutAppOffset = CGSize.zero
    let closeAboutNotif = NotificationCenter.default.publisher(for: NSNotification.Name("closeabout"))

    
    // Message App
    @State var showMessageApp = false
    @State var messageAppPosition = CGPoint(x: 500, y: 220)
    @State var messageDragOffset = CGSize.zero
    @State var messageAppDock = false
    @State var hasCompletedInitialMessage = false
    @State var showStoryAlert = false
    let updateKeynoteZVal = NotificationCenter.default.publisher(for: NSNotification.Name("updateZValKeynote"))
    let closeMessageNotif = NotificationCenter.default.publisher(for: NSNotification.Name("closeMessages"))
    
    // Keynote App
    @State var showKeynoteApp = false
    @State var keynoteAppPosition = CGPoint(x: 400, y: 180)
    @State var keynoteDragOffset = CGSize.zero
    @State var keynoteAppDock = false
    let closeKeynoteNotif = NotificationCenter.default.publisher(for: NSNotification.Name("closeKeynote"))
    
    // Notes App
    @State var showNotesApp = false
    @State var notesAppPosition = CGPoint(x: 600, y: 300)
    @State var notesDragOffset = CGSize.zero
    @State var notesAppDock = false
    let closeNotesNotif = NotificationCenter.default.publisher(for: NSNotification.Name("closeNotes"))
    
    // Countdown App
    @State var showCountdownApp = false
    @State var countdownAppPosition = CGPoint(x: 550, y: 200)
    @State var countdownDragOffset = CGSize.zero
    @State var countdownAppDock = false
    let closeCountdownNotif = NotificationCenter.default.publisher(for: NSNotification.Name("closeCountdown"))
    
    // AR App
    @State var showARExperienceApp = false
    @State var ARExperienceAppAppPosition = CGPoint(x: 450, y: 160)
    @State var ARExperienceAppDragOffset = CGSize.zero
    @State var ARExperienceAppAppDock = false
    let closeARExperienceAppNotif = NotificationCenter.default.publisher(for: NSNotification.Name("closeAR Experience"))
    
    
    var body: some View {
        // Menu Bar
        VStack {
            HStack(alignment: .center) {
                // Initial Menu Bar Items
                Group {
                    Menu {
                        Button("About This Project"){
                            showMainAboutApp = true
                        }
                        Button("Restart Experience"){
                            restartAppNotif = true
                        }
                        Button("Log Out \(personName)"){
                            restartAppNotif = true
                        }
                    } label: {
                        Image(systemName: "apple.logo")
                    }
                    .padding(.leading, 6)
                    .alert("Restart SlideScramble?\n\nAre you sure you would like to restart SlideScramble? All current progress will be lost.", isPresented: $restartAppNotif) {
                        Button("Yes", role: .destructive){
                            hasCompletedInitialMessage = false
                            personName = "WWDC attendee"
                            restartApp.toggle()
                        }
                        
                        Button("Cancel", role: .cancel){}
                    }
                    .background(NavigationLink(destination: StartView(), isActive: $restartApp){})

                    Menu {
                        Button("About \(appName)"){
                            showAboutApp = true
                        }
                        if appName != "SlideScramble" {
                            Button("Quit \(appName)"){
                                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "close\(appName)"), object: self, userInfo: nil)
                            }
                        }
                    } label: {
                        Text(appName)
                    }
                    .id(menuBarID)
                }
                .padding(.leading, 8)
                .font(.system(size: 18, weight: .bold, design: .default))
                
                Group {
                    Menu {
                        Button("Close Window"){
                            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "close\(appName)"), object: self, userInfo: nil)
                        }
                            .disabled(appName == "SlideScramble")
                    } label: {
                        Text("File")
                    }
                    
                    Menu {
                        Button("Hide Window"){
                            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "close\(appName)"), object: self, userInfo: nil)
                        }
                            .disabled(appName == "SlideScramble")
                    } label: {
                        Text("Window")
                    }
                    
                    Button ("Help") {
                        withAnimation {
                            showSpotlight.toggle()
                        }
                    }
                }
                .padding(.leading, 8)
                .font(.system(size: 18, weight: .regular, design: .default))
                
                
                Spacer()
                
                // Menu Bar Icons
                Group {
                    Image(systemName: "moon.fill")
                        .opacity(0.15)
                    Button {
                        withAnimation {
                            showSpotlight.toggle()
                        }
                    } label: {
                        Image(systemName: "magnifyingglass")
                    }
                    Image(systemName: "switch.2")
                    Text("Sun Jun 4  " + time)
                        .padding(.trailing)
                }
                .padding(.leading, 8)
                .font(.system(size: 18, weight: .regular, design: .default))
                
            }
            .frame(minHeight: 34)
            .foregroundColor(.black)
            
            // Needed as the status bar does not hide on Swift Playgrounds via iPad
            .padding(.top)
            
            .background(.white.opacity(0.4))
            .overlay {
                // Message Notification
                if showIntroMessage {
                    HStack {
                        Spacer()
                        
                        InitialMessageView()
                            .background(.ultraThinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                            .frame(width: 400)
                            .shadow(radius: 10)
                            .padding(.top, 160)
                            .overlay {
                                if showIntroMessageSecondary {
                                    Text("Tap on the message from Craig to begin")
                                        .fontWeight(.bold)
                                        .padding()
                                        .background(.ultraThinMaterial)
                                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                        .shadow(radius: 10)
                                        .padding(.top, 320)
                                        .transition(.move(edge: .trailing))
                                }
                            }
                            .onTapGesture {
                                appName = "Messages"
                                showMessageApp = true
                                keynoteZindex = 13
                                withAnimation {
                                    showIntroMessage = false
                                    showIntroMessageSecondary = false
                                    messageAppDock.toggle()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) {
                                        messageAppDock.toggle()
                                    }
                                }
                            }
                    }
                    .transition(.move(edge: .trailing))
                }
            }
            .zIndex(11)
            
            // Desktop Keynote Icon
            HStack {
                Spacer()
                VStack {
                    Image("KeynoteThumbnail")
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 45)
                    
                    Text("WWDC23 Keynote")
                        .foregroundColor(.white)
                        .font(.system(size: 17, weight: .medium, design: .default))
                        .shadow(radius: 10)
                        .multilineTextAlignment(.center)
                        .background(dragKeynote ? .blue : .clear)
                        .padding(1)
                        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                }
                .frame(maxWidth: 100)
            }
            .padding()
            // Open keynote if double tap occurs on file
            .onTapGesture(count: 2) {
                appName = "Keynote"
                showKeynoteApp = true
                withAnimation {
                    keynoteAppDock.toggle()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) {
                        keynoteAppDock.toggle()
                    }
                }
            }
            .offset(x: offset.width, y: offset.height)
            .gesture(
                DragGesture()
                    .onChanged { move in
                        offset = move.translation
                        dragKeynote = true
                        // Calculate if the keynote file is over messages
                        if (move.location.x > messageAppPosition.x - 350 && move.location.x < messageAppPosition.x + 350) && (move.location.y > messageAppPosition.y - 275 && move.location.y < messageAppPosition.y + 275){
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "keynoteOnTop"), object: self, userInfo: nil)
                                hasCompletedInitialMessage = true
                                withAnimation {
                                    offset = .zero
                                    dragKeynote = false
                                }
                            }
                        }
                    }
                    .onEnded {_ in
                        withAnimation {
                            offset = .zero
                        }
                        dragKeynote = false
                    }
            )
            .zIndex(keynoteZindex)
            
            // App Stack
            ZStack {
                
                // Message App
                if showMessageApp {
                    MessageApp(hasCompletedInitialMessage: hasCompletedInitialMessage)
                        .frame(maxWidth: 700, maxHeight: 550)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .position(messageAppPosition)
                        .offset(messageDragOffset)
                        .onTapGesture {
                            appName = "Messages"
                            menuBarID += 1
                        }
                        .gesture (
                            DragGesture()
                                .onChanged { move in
                                    messageDragOffset = move.translation
                                }
                                .onEnded { move in
                                    messageAppPosition = messageAppPosition + move.translation
                                    messageDragOffset = CGSize.zero
                                }
                        )
                        .zIndex(appName == "Messages" ? 14 : 13)
                        .shadow(radius: 10)
                }
                
                // Keynote App
                if showKeynoteApp {
                    KeynoteApp()
                        .frame(maxWidth: 700, maxHeight: 530)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .position(keynoteAppPosition)
                        .offset(keynoteDragOffset)
                        .onTapGesture {
                            appName = "Keynote"
                            menuBarID += 1
                        }
                        .gesture (
                            DragGesture()
                                .onChanged { move in
                                    keynoteDragOffset = move.translation
                                }
                                .onEnded { move in
                                    keynoteAppPosition = keynoteAppPosition + move.translation
                                    keynoteDragOffset = CGSize.zero
                                }
                        )
                        .zIndex(appName == "Keynote" ? 14 : 13)
                        .shadow(radius: 10)
                }
                
                // Notes App
                if showNotesApp {
                    NotesApp()
                        .frame(maxWidth: 700, maxHeight: 550)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .position(notesAppPosition)
                        .offset(notesDragOffset)
                        .onTapGesture {
                            appName = "Notes"
                            menuBarID += 1
                        }
                        .gesture (
                            DragGesture()
                                .onChanged { move in
                                    notesDragOffset = move.translation
                                }
                                .onEnded { move in
                                    notesAppPosition = notesAppPosition + move.translation
                                    notesDragOffset = CGSize.zero
                                }
                        )
                        .zIndex(appName == "Notes" ? 14 : 13)
                        .shadow(radius: 10)
                        
                }
                
                // Countdown App
                if showCountdownApp {
                    CountdownApp()
                        .frame(maxWidth: 650, maxHeight: 520)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .position(countdownAppPosition)
                        .offset(countdownDragOffset)
                        .onTapGesture {
                            appName = "Countdown"
                            menuBarID += 1
                        }
                        .gesture (
                            DragGesture()
                                .onChanged { move in
                                    countdownDragOffset = move.translation
                                }
                                .onEnded { move in
                                    countdownAppPosition = countdownAppPosition + move.translation
                                    countdownDragOffset = CGSize.zero
                                }
                        )
                        .zIndex(appName == "Countdown" ? 14 : 13)
                        .shadow(radius: 10)
                        
                }
                
                //AR Experience App
                if showARExperienceApp {
                    ARExperienceApp()
                        .frame(maxWidth: 650, maxHeight: 520)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .position(ARExperienceAppAppPosition)
                        .offset(ARExperienceAppDragOffset)
                        .onTapGesture {
                            appName = "AR Experience"
                            menuBarID += 1
                        }
                        .gesture (
                            DragGesture()
                                .onChanged { move in
                                    ARExperienceAppDragOffset = move.translation
                                }
                                .onEnded { move in
                                    ARExperienceAppAppPosition = ARExperienceAppAppPosition + move.translation
                                    ARExperienceAppDragOffset = CGSize.zero
                                }
                        )
                        .zIndex(appName == "AR Experience" ? 14 : 13)
                        .shadow(radius: 10)
                        
                }
                
                // Spotlight/Help
                if showSpotlight {
                    SpotlightApp()
                        .frame(maxWidth: 700, maxHeight: 600)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .padding()
                        .offset(y: -100)
                        .zIndex(15)
                }
                
                // About App goes last to stay on top
                if showAboutApp {
                    AboutApp(appPass: appName)
                        .frame(maxWidth: 410, maxHeight: 230)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .position(aboutAppPosition)
                        .offset(aboutAppOffset)
                        .shadow(radius: 10)
                        .gesture (
                            DragGesture()
                                .onChanged { move in
                                    aboutAppOffset = move.translation
                                }
                                .onEnded { move in
                                    aboutAppPosition = aboutAppPosition + move.translation
                                    aboutAppOffset = CGSize.zero
                                }
                        )
                        .zIndex(15)
                }
                
                
                // About app for first menu
                if showMainAboutApp {
                    AboutApp(appPass: "SlideScramble")
                        .frame(maxWidth: 410, maxHeight: 230)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .position(aboutAppPosition)
                        .offset(aboutAppOffset)
                        .shadow(radius: 10)
                        .gesture (
                            DragGesture()
                                .onChanged { move in
                                    aboutAppOffset = move.translation
                                }
                                .onEnded { move in
                                    aboutAppPosition = aboutAppPosition + move.translation
                                    aboutAppOffset = CGSize.zero
                                }
                        )
                        .zIndex(15)
                }
            }
            .zIndex(12)
            
            Spacer()
            
            // Dock Contents
            if showDock {
                HStack(spacing: 20) {

                    Image("SlideScrambleIcon")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .onTapGesture {
                            appName = "SlideScramble"
                        }
                        .overlay {
                            Image(systemName: "circle.fill")
                                .font(.system(size: 5, weight: .bold, design: .default))
                                .offset(y: 38)
                            
                        }
                    
                    Image("MessageIcon")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .offset(y: messageAppDock ? -12 : 0)
                        .animation(.easeOut(duration: 0.3).repeatCount(1, autoreverses: true), value: messageAppDock)
                        .overlay {
                            if showMessageApp {
                                Image(systemName: "circle.fill")
                                    .font(.system(size: 5, weight: .bold, design: .default))
                                    .offset(y: 38)
                            }
                        }
                        .onTapGesture {
                            withAnimation() {
                                if !showMessageApp {
                                    messageAppDock.toggle()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) {
                                        messageAppDock.toggle()
                                    }
                                }
                            }
                            if showIntroMessage {
                                keynoteZindex = 13
                                showIntroMessage = false
                            }
                            appName = "Messages"
                            showMessageApp = true
                        }
                    
                    Image("KeynoteIcon")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .offset(y: keynoteAppDock ? -12 : 0)
                        .animation(.easeOut(duration: 0.3).repeatCount(1, autoreverses: true), value: keynoteAppDock)
                        .overlay {
                            if showKeynoteApp {
                                Image(systemName: "circle.fill")
                                    .font(.system(size: 5, weight: .bold, design: .default))
                                    .offset(y: 38)
                            }
                        }
                        .onTapGesture {
                            withAnimation() {
                                if !showKeynoteApp {
                                    keynoteAppDock.toggle()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) {
                                        keynoteAppDock.toggle()
                                    }
                                }
                            }
                            appName = "Keynote"
                            showKeynoteApp = true
                        }
                    
                    Image("NotesIcon")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .offset(y: notesAppDock ? -12 : 0)
                        .animation(.easeOut(duration: 0.3).repeatCount(1, autoreverses: true), value: notesAppDock)
                        .overlay {
                            if showNotesApp {
                                Image(systemName: "circle.fill")
                                    .font(.system(size: 5, weight: .bold, design: .default))
                                    .offset(y: 38)
                            }
                        }
                        .onTapGesture {
                            withAnimation() {
                                if !showNotesApp {
                                    notesAppDock.toggle()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) {
                                        notesAppDock.toggle()
                                    }
                                }
                            }
                            appName = "Notes"
                            showNotesApp = true
                        }
                    
                    Image("CountdownIcon")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .offset(y: countdownAppDock ? -12 : 0)
                        .animation(.easeOut(duration: 0.3).repeatCount(1, autoreverses: true), value: countdownAppDock)
                        .overlay {
                            if showCountdownApp {
                                Image(systemName: "circle.fill")
                                    .font(.system(size: 5, weight: .bold, design: .default))
                                    .offset(y: 38)
                            }
                        }
                        .onTapGesture {
                            withAnimation() {
                                if !showCountdownApp {
                                    countdownAppDock.toggle()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) {
                                        countdownAppDock.toggle()
                                    }
                                }
                            }
                            appName = "Countdown"
                            showCountdownApp = true
                        }
                    
                    Image("ARIcon")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .offset(y: ARExperienceAppAppDock ? -12 : 0)
                        .animation(.easeOut(duration: 0.3).repeatCount(1, autoreverses: true), value: ARExperienceAppAppDock)
                        .overlay {
                            if showARExperienceApp {
                                Image(systemName: "circle.fill")
                                    .font(.system(size: 5, weight: .bold, design: .default))
                                    .offset(y: 38)
                            }
                        }
                        .onTapGesture {
                            if !hasCompletedInitialMessage {
                                showStoryAlert = true
                            } else {
                                withAnimation() {
                                    if !showARExperienceApp {
                                        ARExperienceAppAppDock.toggle()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) {
                                            ARExperienceAppAppDock.toggle()
                                        }
                                    }
                                }
                                appName = "AR Experience"
                                showARExperienceApp = true
                            }
                        }
                }
                .zIndex(12)
                .padding()
                .background(.ultraThinMaterial.opacity(0.85))
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .transition(.move(edge: .bottom))
                .alert("Complete the Story!\n\nSend over the Keynote file first to save WWDC once more! Once you are done, feel free to come back and explore!", isPresented: $showStoryAlert) {
                    Button("OK", role: .cancel){}
                }
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                withAnimation(.easeOut(duration: 0.5)) {
                    showDock = true
                }
            }
            
            if !hasCompletedInitialMessage {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.25) {
                    withAnimation(.easeOut(duration: 0.75)) {
                        showIntroMessage = true
                    }
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                    withAnimation(.easeOut(duration: 0.50)) {
                        showIntroMessageSecondary = true
                    }
                }
            }
        }
        
        .preferredColorScheme(.light)
        .background(
            Image("DesktopBackground")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
                .onTapGesture {
                    appName = "SlideScramble"
                }
            
        )
        .onAppear {
            time = "\(Date().formatted(.dateTime.hour().minute()))"
        }
        .onReceive(clockTimer) {_ in
            time = "\(Date().formatted(.dateTime.hour().minute()))"
        }
        .onReceive(updateKeynoteZVal) {_ in
            keynoteZindex = 10
        }
        .onReceive(closeAboutNotif) {_ in
            showAboutApp = false
            showMainAboutApp = false
        }
        .onReceive(closeMessageNotif) {_ in
            showMessageApp = false
            appName = "SlideScramble"
        }
        .onReceive(closeKeynoteNotif) {_ in
            showKeynoteApp = false
            appName = "SlideScramble"
        }
        .onReceive(closeNotesNotif) {_ in
            showNotesApp = false
            appName = "SlideScramble"
        }
        .onReceive(closeCountdownNotif) {_ in
            showCountdownApp = false
            appName = "SlideScramble"
        }
        .onReceive(closeARExperienceAppNotif) {_ in
            showARExperienceApp = false
            appName = "SlideScramble"
        }
        .onReceive(closeSpotlight) {_ in
            withAnimation {
                showSpotlight = false
            }
        }
    }
}

extension CGPoint {
    static func +(left: CGPoint, right: CGSize) -> CGPoint {
        CGPoint(x: left.x + right.width, y: left.y + right.height)
    }
}

struct DesktopView_Previews: PreviewProvider {
    static var previews: some View {
        DesktopView()
    }
}

struct InitialMessageView: View {
    var body: some View {
        ZStack {
            HStack {
                ZStack {
                    Color(red: 0.76, green: 0.75, blue: 0.99)
                    Text("🍎")
                        .foregroundColor(Color(red: 0.92, green: 0.30, blue: 0.27))
                        .font(.system(size: 25, weight: .bold))
                }
                .frame(maxWidth: 40, maxHeight: 40)
                .cornerRadius(25)
                .padding(.leading, 15)
                
                VStack(alignment: .leading) {
                    Group {
                        Text("Craig Federighi")
                        Text("Apple Event Group Chat")
                    }
                    .font(.system(size: 15, weight: .bold, design: .default))
                    
                    Text("Hey \(personName)! We need your help once more!")
                        .font(.system(size: 15, weight: .regular, design: .default))
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.leading, 2)
                }
                .padding(.vertical)
            }
            .padding(.vertical)
            .overlay {
                HStack {
                    Image("MessageIcon")
                        .resizable()
                        .frame(width: 17, height: 17)
                    Spacer()
                }
                .padding(.leading, 40)
                .padding(.top, 25)
            }
        }
        .frame(maxHeight: 85)
        .padding(.trailing, 15)
    }
}
