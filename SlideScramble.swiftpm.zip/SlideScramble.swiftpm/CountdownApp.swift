//
//  CountdownApp.swift
//  SlideScramble
//
//  Created by Vedant Malhotra on 4/18/23.
//

import SwiftUI

struct CountdownApp: View {
    
    @State var dateCountdown = 0
    
    var body: some View {
        HStack(spacing: 0) {
            // Countdown App Sidebar
            VStack {
                Button {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeCountdown"), object: self, userInfo: nil)
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(Color(red: 0.93, green: 0.38, blue: 0.41))
                        .font(.system(size: 32, weight: .regular, design: .default))
                }
                .padding(.trailing, 30)
                .padding(.top)
                Spacer()
            }
            .frame(width: 100)
            .background(.thinMaterial)
            
            VStack(spacing: 20) {
                
                Spacer()
                
                HStack {
                    Spacer()
                    Image(systemName: "swift")
                        .font(.system(size: 80, weight: .bold, design: .rounded))
                        .padding(.top, 30)
                    Spacer()
                }
                
                Text("WWDC 2023")
                    .font(.system(size: 60, weight: .bold, design: .rounded))
                    .padding()
                
                Text("WWDC 2023 will be held from June 5th to June 9th!")
                    .font(.system(size: 22, weight: .medium, design: .rounded))
                
                Text("Days until WWDC 2023:")
                    .font(.system(size: 30, weight: .medium, design: .rounded))
                
                
                Text("\(dateCountdown + 1)")
                    .font(.system(size: 100, weight: .bold, design: .rounded))
                
                Spacer()
                
            }
            .padding(.horizontal)
            .background(.black)
            .foregroundColor(.white)
            .onAppear {
                // Calculate Date
                let dubDub23Date = "2023-06-05"
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy-MM-dd"
                
                let dubDub23Formatted = formatter.date(from: dubDub23Date)
                
                let currentDate = Date()
                let components = Set<Calendar.Component>([.day])
                let difference = Calendar.current.dateComponents(components, from: currentDate, to: dubDub23Formatted!)
                
                dateCountdown = difference.day!
            }
        }
    }
}

struct CountdownApp_Previews: PreviewProvider {
    static var previews: some View {
        CountdownApp()
    }
}
